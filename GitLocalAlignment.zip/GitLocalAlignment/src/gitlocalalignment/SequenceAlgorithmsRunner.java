
package gitlocalalignment;

public class SequenceAlgorithmsRunner 
{
    public static void main(String args[])
    {
        //-----  Parameters -----//
        int match = 2;
        int mismatch = -1;
        int gap = -2;
        
        //----- DNA Sequences -----//
        String dna1 = "agc";
        String dna2 = "aaac";
        
        //----- Sequence Algorithm Initialization -----//
        LocalSequenceAlignment LSL = new LocalSequenceAlignment(dna1,dna2,match,mismatch,gap);
        
        //----- Runner -----//
        LSL.runner();
        
    }

}
